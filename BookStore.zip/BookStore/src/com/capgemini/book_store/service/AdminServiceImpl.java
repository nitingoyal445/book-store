package com.capgemini.book_store.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.book_Store.bean.Book;
import com.capgemini.book_Store.bean.Category;
import com.capgemini.book_Store.bean.Customer;
import com.capgemini.book_store.DAO.IBookRepo;
import com.capgemini.book_store.DAO.ICategoryRepo;
import com.capgemini.book_store.DAO.ICustomerRepo;
import com.capgemini.book_store.DAO.IOrderRepo;
import com.capgemini.book_store.DAO.IReviewRepo;

@Service
public class AdminServiceImpl implements IAdminService {

	
	@Autowired
	IAdminService iAdminService;
	
	@Autowired
	ICustomerRepo customerRepo;
	
	@Autowired 
	ICategoryRepo categoryRepo;
	
	@Autowired
	IOrderRepo orderRepo;
	
	@Autowired
	IReviewRepo reviewRepo;
	
	@Autowired
	IBookRepo bookRepo;
	

	@Override
	public List<Customer> showAllCustomer()
	{
		
		return customerRepo.findAll();
	}
	
	
	@Override
	public boolean deleteCustomer(int customerId) {
		
		if(reviewRepo.findByCustomer(customerRepo.findOne(customerId)) != null  || orderRepo.findByCustomer(customerRepo.findOne(customerId))!=null) 
		{  return false;  }
		customerRepo.delete(customerId);
		return true;
	}
	
	
	@Override
	public Customer createCustomer(Customer customer) {
		if(customerRepo.findByEmailId(customer.getEmailId()) != null) {
			return null;
		}
		return customerRepo.save(customer);
	}
	
	
	@Override
	public boolean updateCustomer(Customer customer) {
		
		Customer cust=customerRepo.findOne(customer.getCustomerId());
		cust.setCustomerName(customer.getCustomerName());
		cust.setCity(customer.getCity());
		cust.setCountry(customer.getCountry());
		cust.setMobileNumber(customer.getMobileNumber());
		cust.setZipcode(customer.getZipcode());
		cust.setAddress(customer.getAddress());
		if(customerRepo.findByEmailId(customer.getEmailId()) == null) {
			cust.setEmailId(cust.getEmailId());
		}
		cust.setEmailId(customer.getEmailId());
		cust.setPassword(customer.getPassword());
		return true;
		
	}
	
	
	@Override
	public List<Category> showAllCategory()
	{
		List<Category> li= categoryRepo.findAll();
		return li;
	}
	
	
	@Override
	public boolean deleteCategory(int categoryId) {
		
		if(bookRepo.findByCategory(categoryRepo.findOne(categoryId)) != null) {
			return false;
		}
		categoryRepo.delete(categoryId);
		return true;
	}
	
	@Override
	public Category createCategory(Category category) {
		
		return categoryRepo.save(category);
	}
	
	
	@Override
	public Category updateCategory(String categoryName, String upcategoryName) {
		
		List<Category> li = categoryRepo.findAll();
		for(Category c : li)
		{
			if(c.getCategoryName().equals(categoryName))
			{
				c.getCategoryName().remove(categoryName);
				c.getCategoryName().add(upcategoryName);
			}
		}
		return null;
		
		
	}
	@Override
	public List<Book> searchByCategory(String categoryName){
				
		return bookRepo.findByCategory(categoryName);
		
		
	}

}
