package com.capgemini.book_store.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.book_Store.bean.Customer;

public interface ICustomerRepo extends JpaRepository<Customer, Integer> {
	
	Customer findByEmailId(String email);

}
