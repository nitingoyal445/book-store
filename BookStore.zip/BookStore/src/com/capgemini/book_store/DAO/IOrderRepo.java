package com.capgemini.book_store.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.book_Store.bean.Customer;
import com.capgemini.book_Store.bean.Order;

public interface IOrderRepo extends JpaRepository<Order, Integer> {

	Customer findByCustomer(Customer customer);
}
