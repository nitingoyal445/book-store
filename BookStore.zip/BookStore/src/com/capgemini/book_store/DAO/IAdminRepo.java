package com.capgemini.book_store.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.book_Store.bean.Admin;

public interface IAdminRepo extends JpaRepository<Admin, Integer> {


}
