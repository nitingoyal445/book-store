import { Component } from '@angular/core';


@Component({
  selector: 'app-createNewBook',
  templateUrl: './app.createNewBookComponent.html',
 
})
export class createNewBookComponent {
}