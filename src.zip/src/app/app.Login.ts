export class  Login {

  public email:String ;
  public password:string;
  public user:string;
    constructor(
      user:string,
    email: string,
   
    password: string
    
    ) { 
      this.user=user;
       this.email = email;
      this.password = password;
      
     }
  
  }