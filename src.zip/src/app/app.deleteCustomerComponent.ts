import { Component, OnInit  } from '@angular/core';
import { ICustomer } from './app.ICustomer';
import { deleteCustomerService } from './app.deleteCustomerService';


@Component({
  selector: 'app-deleteCustomer',
  templateUrl: './app.deleteCustomerComponent.html',
  providers:[deleteCustomerService]
 
})
export class deleteCustomerComponent implements OnInit {


    customers:ICustomer[];


    constructor(private cusService:deleteCustomerService){}

    ngOnInit():void{
        this.customers=this.cusService.getAllCustomer();
       
        
    }

   
}