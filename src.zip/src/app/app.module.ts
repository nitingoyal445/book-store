﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { HeroFormComponent } from './hero-form.component';
import {createNewBookComponent} from './app.createNewBookComponent';
import {createNewCustomer} from './app.createNewCustomer';
import {addAdminComponent} from './app.addAdminComponent';
import { categoryComponent } from './app.categoryComponent';
import {FormsModule} from '@angular/forms';


@NgModule({
    imports: [
        BrowserModule,  FormsModule
        
    ],
    declarations: [
        AppComponent, HeroFormComponent, createNewCustomer, addAdminComponent, categoryComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }