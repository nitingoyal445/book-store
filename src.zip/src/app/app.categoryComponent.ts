import { Component } from '@angular/core';


@Component({
  selector: 'app-category',
  templateUrl: './app.categoryComponent.html',
 
})
export class categoryComponent {
}