export interface ICustomer{


    customerId:number;
    emailId:string;
    customerName:string;
    city:string;
    country:string;
    registrationDate:string;
    mobileNumber:string;
    address:string;
    zipcode:string;
    password:string;

}