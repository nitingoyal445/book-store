import { ICustomer } from "./app.ICustomer";
import { Injectable } from "@angular/core";
@Injectable()
export class deleteCustomerService{
    getAllCustomer():ICustomer[]{
        return[
            {customerId:null,
                emailId:null,
                customerName:null,
                city:"Agra",
                country:"India",
                registrationDate:"12/2/2012",
                mobileNumber:"1234567898",
                address:"Agra",
                zipcode:"123456",
                password:"abc123"
            },
            {customerId:null,
                emailId:null,
                customerName:null,
                city:"Agra",
                country:"India",
                registrationDate:"12/2/1234",
                mobileNumber:"954786213",
                address:"Agra",
                zipcode:"654987",
                password:"abc12345"
            }
   ];

    }
}