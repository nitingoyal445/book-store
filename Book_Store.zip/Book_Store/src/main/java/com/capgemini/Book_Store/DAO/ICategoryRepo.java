package com.capgemini.Book_Store.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.Book_Store.bean.Category;

public interface ICategoryRepo extends JpaRepository<Category, Integer> {
	
	Category findByCategoryName(String catName);

}
